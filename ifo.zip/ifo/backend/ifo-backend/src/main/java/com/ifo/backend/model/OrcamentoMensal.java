package com.ifo.backend.model;

import jakarta.persistence.*;
import java.math.BigDecimal;

@Entity
@Table(name = "orcamento_mensal")
public class OrcamentoMensal {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long idOrcamento;

    @Column(name = "id_usuario", nullable = false)
    private Long idUsuario;

    @Column(name = "id_categoria", nullable = false)
    private Long idCategoria;

    @Column(name = "limite_valor", nullable = false, precision = 10, scale = 2)
    private BigDecimal limiteValor;

    @Column(name = "mes", nullable = false)
    private Integer mes;

    @Column(name = "ano", nullable = false)
    private Integer ano;

    @Column(name = "categoria", nullable = false)
    private String categoria; // "NECESSIDADE", "LAZER" ou "INVESTIMENTO"

    // Getter e Setter
    public String getCategoria() {
        return categoria;
    }

    public void setCategoria(String categoria) {
        this.categoria = categoria;
    }

    public OrcamentoMensal() {}

    public OrcamentoMensal(Long idUsuario, Long idCategoria, BigDecimal limiteValor, Integer mes, Integer ano) {
        this.idUsuario = idUsuario;
        this.idCategoria = idCategoria;
        this.limiteValor = limiteValor;
        this.mes = mes;
        this.ano = ano;
    }

    // Getters e Setters
    public Long getIdOrcamento() { return idOrcamento; }
    public void setIdOrcamento(Long idOrcamento) { this.idOrcamento = idOrcamento; }
    public Long getIdUsuario() { return idUsuario; }
    public void setIdUsuario(Long idUsuario) { this.idUsuario = idUsuario; }
    public Long getIdCategoria() { return idCategoria; }
    public void setIdCategoria(Long idCategoria) { this.idCategoria = idCategoria; }
    public BigDecimal getLimiteValor() { return limiteValor; }
    public void setLimiteValor(BigDecimal limiteValor) { this.limiteValor = limiteValor; }
    public Integer getMes() { return mes; }
    public void setMes(Integer mes) { this.mes = mes; }
    public Integer getAno() { return ano; }
    public void setAno(Integer ano) { this.ano = ano; }
}